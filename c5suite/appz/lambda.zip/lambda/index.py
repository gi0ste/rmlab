import boto3
import json
import logging
import os
import random
from datetime import datetime

def handler(event, context):
    print ("Event Data is :")
    print (event)

    client = boto3.resource ('dynamodb')
   
    time_now = datetime.now ().strftime ('%Y-%m-%d %H:%M:%S')

    _keys = event['Records'][0]['dynamodb']['Keys']

    ran_num = random.randint (1000, 10000)

    print ("random number ", ran_num)
    
    event_source_arn = event['Records'][0]['eventSourceARN']
    event_name=event['Records'][0]['eventName']
    print("Event name is")
    print(event_name)
    temp_list = event_source_arn.split (':')
    temp_list1 = temp_list[5].split ('/')
    table_name = temp_list1[1]

    table = client.Table (table_name)

    # key_id=(_keys[0])
    _keys_k = list (_keys.keys ())[0]
    values_dict = _keys.get (_keys_k)
    _keys_v = list (values_dict.values ())[0]
    print (_keys_v)

    uuid = _keys_v + str (ran_num)

    print (uuid)
    print ("keys comparison")
    
    print (_keys_v)

    
    if event_name=='INSERT':
        print ("Updating fields....")
        table.update_item (
            Key={_keys_k: _keys_v},
            UpdateExpression='SET trigger_time = :val1, generated_id = :val2',
            ExpressionAttributeValues={
                ':val1': time_now,
                ':val2': uuid

            }

        )
            

    print("updated fields...")

    return True

