import flask
import werkzeug.datastructures
from werkzeug.datastructures import ImmutableMultiDict
from os import getenv
import pymysql
from pymysql.err import OperationalError
from flask import Flask, render_template

app = Flask(__name__, template_folder="templates")
# TODO(developer): specify SQL connection details
CONNECTION_NAME = getenv(
    'INSTANCE_CONNECTION_NAME',
    '<YOUR INSTANCE CONNECTION NAME>')
DB_USER = getenv('MYSQL_USER', '<YOUR DB USER>')
DB_PASSWORD = getenv('MYSQL_PASSWORD', '<YOUR DB PASSWORD>')
DB_NAME = getenv('MYSQL_DATABASE', '<YOUR DB NAME>')
mysql_config = {
    'user': DB_USER,
    'password': DB_PASSWORD,
    'db': DB_NAME,
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor,
    'autocommit': True
}
# PyMySQL does not include support for connection pooling
mysql_conn = None


def __get_cursor():
    """
    Helper function to get a cursor
      PyMySQL does NOT automatically reconnect,
      so we must reconnect explicitly using ping()
    """
    try:
        return mysql_conn.cursor()
    except OperationalError:
        mysql_conn.ping(reconnect=True)
        return mysql_conn.cursor()

def mysql_demo_table(answers_data):
    global mysql_conn
    if not mysql_conn:
        try:
            mysql_conn = pymysql.connect(**mysql_config)
        except OperationalError:
            # If production settings fail, use local development ones
            mysql_config['unix_socket'] = f'/cloudsql/{CONNECTION_NAME}'
            mysql_conn = pymysql.connect(**mysql_config)

    # Remember to close SQL resources declared while running this function.
    # Keep any declared in global scope (e.g. mysql_conn) for later reuse.
    with __get_cursor() as cursor:

        sqlQuery = "CREATE TABLE IF NOT EXISTS dataans (fullname varchar(32), email varchar(32),Q1 varchar(31),Q2 varchar(31),Q3 varchar(31));"
        results = cursor.execute(sqlQuery)
        sql = 'insert into dataans(fullname,email,' \
              'Q1,Q2,Q3) ' \
              'values(%s,%s,%s,%s,%s);'
        values = (answers_data['fullname'], answers_data['email'], answers_data['Q1'], answers_data['Q2'],
                  answers_data['Q3'])

        cursor.execute(sql, values)
        cursor.close()
        # cursor.execute(transaction_sql,answers_data)
        # return "Data saved succesfully"


def get_data(request):
    if request.method == 'POST':
        result = request.form
        result = result.to_dict(flat=False)
        for key, values in result.items():
            result[key] = values[0]
        score = 0
        if result['Q1'] == 'maison':
            result['Q1'] = 'maison'
            score = score + 1            
        else:
            result['Q1'] = 'Wrong answer'
        if result['Q2'] == 'poisson':
            result['Q2'] = 'poisson'
            score = score + 1
        else:
            result['Q2'] = 'Wrong answer'
        if result['Q3'] == 'valise':
            result['Q3'] = 'valise'
            score = score + 1
        else:
            result['Q3'] = 'Wrong answer'
        result["score"] = score
        #return str(result)
        mysql_demo_table(result)
        return render_template("result.html", result=result)
    return render_template('index.html')


