source /usr/local/cliqr/etc/userenv
