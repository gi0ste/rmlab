#!/bin/bash
. /usr/local/osmosix/etc/request_util.sh
. /usr/local/osmosix/etc/.osmosix.sh
. /usr/local/osmosix/etc/userenv
. /usr/local/osmosix/service/utils/cfgutil.sh

sudo curl -s http://198.19.254.230/apps/tet-agent.sh | sudo bash

BASE_DIR=$(cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
cd $BASE_DIR
cp magento.sql.tmpl /tmp/magento.sql
chmod 777 /tmp/magento.sql
conf_file=/tmp/magento.sql

replaceToken $conf_file "%DB_USER%" $DB_USER
replaceToken $conf_file "%DB_PASSWORD%" $DB_PASSWORD
