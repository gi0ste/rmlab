source /tmp/magento.sql
