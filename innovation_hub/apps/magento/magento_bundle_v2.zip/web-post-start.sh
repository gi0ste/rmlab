#!/bin/bash

. /usr/local/osmosix/etc/userenv
. /usr/local/osmosix/service/utils/cfgutil.sh

PRODUCT=Magento

Apache_IP=$CliqrTier_apache2_0_PUBLIC_IP
[ -z $Apache_IP ] && Apache_IP=$CliqrTier_apache2_0_IP
Database_IP=$CliqrTier_mysql_1_IP

if [ -z $Apache_IP ]; then
  echo Could not determine Web Server IP Address
  exit 4
elif [ -z $Database_IP ]; then
  echo Could not determine Database Server IP Address
  exit 5
fi

echo DB:$Database_IP, Web:$Apache_IP
sleep 1

WEBROOT=/var/www

cd $WEBROOT
if [ $? -ne 0 ]; then echo "ERROR: Could not CD to $WEBROOT"; exit 1; fi

iRetries=9
iPause=10

echo -n "Configuring $PRODUCT ... "
while [ $iRetries -ge 0 ]; do

  sudo php -f install.php -- --license_agreement_accepted yes \
      --locale en_GB --timezone "Europe/London" --default_currency GBP \
      --db_host $Database_IP --db_name magento --db_user $DB_USER --db_pass $DB_PASSWORD \
      --db_prefix magento_ \
      --url "http://${Apache_IP}/" --use_rewrites yes \
      --use_secure no \ # yes --secure_base_url "https://${Apache_IP}/" --use_secure_admin yes \
      --admin_lastname Owner --admin_firstname Store --admin_email "admin@dcloud.cisco.com" \
      --admin_username $ADMIN_USER --admin_password $ADMIN_PASS # \
#      --encryption_key "Encryption Key"

  er=$?
  if [ $er -eq 0 ]; then
    echo "Success!"
    exit 0
  fi

  echo "Failed! Error code: $er, retries left: $iRetries"
  sleep $iPause
  ((iRetries--))

done

echo "Failed to perform the initial $PRODUCT configuration"
exit 1

