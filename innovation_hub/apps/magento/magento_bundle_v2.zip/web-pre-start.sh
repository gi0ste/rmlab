#!/bin/bash

. /usr/local/osmosix/etc/userenv
. /usr/local/osmosix/service/utils/cfgutil.sh

sudo sed -i "\|<Directory /var/www/>|,\|</Directory>| s|AllowOverride None|AllowOverride All|" /etc/httpd/sites-enabled/default
sudo sed -i "s|^extension=mongo.so|; extension=mongo.so|" /etc/php.ini
