#!/bin/bash

/etc/init.d/nginx status > /dev/null
if [ $? -ne 0 ]; then exit 0; fi

CONF="/etc/nginx/nginx.conf"
SECTION="upstream marathon"
CONN_TIMEOUT=3

SERVER_RECORD_LIST=$( \
  sed -n "/$SECTION{/,/}/p" $CONF | sed -e "s/.*$SECTION{//" -e "s/}//" -e "/^\s*$/d" \
   | grep 'server ' | xargs )

SERVER_LIST=$(echo $SERVER_RECORD_LIST | sed -e 's/\s*server\s*\([^;]*\)/\1/g' -e 's/\s[^;]*//g' )

IFS=';' read -r -a SERVERS <<< "$SERVER_LIST"

check_server(){
  local -a RET
  IFS=$'\n' RET=($(curl -m $CONN_TIMEOUT -i $1 2>/dev/null | tr -d '\r' | egrep "HTTP/1.1 302|X-Marathon-Via"))
  local ER=$?
  local LR=${#RET[@]}
  if [ $ER -eq 0 ] && [ $LR -eq 1 ]; then
    echo $1 up
  else
    echo $1 down
  fi
}

declare -a DESIRED
IFS=$'\n' DESIRED=($(
  for S in "${SERVERS[@]}"; do
    check_server "$S" &
  done
  wait
))

fRELOAD=false
for D in "${DESIRED[@]}"; do
  SRV_URL=$(echo $D | cut -d' ' -f1)
  SRV_STATE=$(echo $D | cut -d' ' -f2)
  SRV_REC=$(echo "server $SRV_URL $SRV_STATE;" | sed 's|\s*up;$|;|')
  if ! $(echo $SERVER_RECORD_LIST | grep -q "$SRV_REC"); then
    echo "$(date +'%F %R:%S') - Updating server $SRV_URL to $SRV_STATE"
    sed -i "/$SECTION{/,/}/ s/server $SRV_URL[^;]*;/$SRV_REC/" $CONF
    fRELOAD=true
  fi
done

if $fRELOAD; then echo -n "$(date +'%F %R:%S') - "; /etc/init.d/nginx reload; fi
