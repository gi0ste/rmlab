#!/bin/bash

( 
set -x

source /usr/local/osmosix/etc/userenv
source /usr/local/osmosix/etc/.osmosix.sh

if [ ! -z $INSTALL_TET_AGENT ]; then
  sudo curl -s http://198.19.254.230/apps/tet-agent.sh | sudo bash
fi

for N in "repos.mesosphere.io" "repos.mesosphere.com"; do
  for X in $(seq 1 1 100); do
    nslookup $N > /dev/null 2>&1
    if [ $? -eq 0 ]; then break; fi
  done
done

BASE_DIR=$(cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
sudo yum -y localinstall $BASE_DIR/mesosphere-el-repo-6-2.noarch.rpm
sudo yum -y install mesos marathon
sudo yum -y localinstall $BASE_DIR/cloudera-cdh-4-0.x86_64.rpm
sudo yum -y install zookeeper zookeeper-server


### Ensure hostname is registered with DNS
if ! hostname -f > /dev/null 2>&1; then
  dom=$(cat /etc/resolv.conf | egrep -m1 "search|domain" | cut -d' ' -f2)
  echo Adding DNS A Record: ${cliqrNodeHostname}.${dom} => $cliqrNodePrivateIp
  echo -e "update add ${cliqrNodeHostname}.${dom} 86400 a $cliqrNodePrivateIp\nsend" | nsupdate
fi


### Configure Zookeeper
#Define Master IPs/Port Endpoints to the Zookeeper configuration
echo zk://${CliqrTier_MasterNode_IP} | sed -e 's|,|:2181,|g' -e 's|$|:2181/mesos|' | sudo tee /etc/mesos/zk > /dev/null

#Add all Masters to the Zookeeper config, using unique IDs and IPs
(
  i=1; IFS=","
  for s in ${CliqrTier_MasterNode_IP}; do
    printf "server.%s=%s:2888:3888\n" "$i" "$s"
    (( i++ ))
  done | sudo tee -a /etc/zookeeper/conf/zoo.cfg > /dev/null
)

#Define unique ID for the Zookeeper service on each Master
cat /etc/zookeeper/conf/zoo.cfg | grep "$cliqrNodePrivateIp" | cut -d'=' -f1 | cut -d'.' -f2 | sudo tee /etc/zookeeper/conf/myid > /dev/null


### Configure Mesos
#Configure IP Address and Hostname for each Master
echo "$cliqrNodePrivateIp" | sudo tee /etc/mesos-master/ip | sudo tee /etc/mesos-master/hostname > /dev/null

#Define the name of the cluster which is human readable at mesos web console
echo $clustername | sudo tee /etc/mesos-master/cluster > /dev/null

#Define the quorum value which is always be over clustersize/2
qf=$(echo "scale=2; $minClusterSize/2" | bc)
printf "%.*f" 0 $qf | sudo tee /etc/mesos-master/quorum > /dev/null


### Configure Marathon
if [ ! -d /etc/marathon/conf ]; then sudo mkdir -p /etc/marathon/conf; fi

#Define the hostname for the Marathon service, use the same one as Mesos
sudo cp /etc/mesos-master/hostname /etc/marathon/conf/

#Define endpoints for Marathon, following the Mesos list
# (but replace the trailing "/mesos" with "/marathon"
cat /etc/mesos/zk | sudo tee /etc/marathon/conf/master | sed -e "s|/mesos|/marathon|" | sudo tee /etc/marathon/conf/zk > /dev/null


### Initialise Zookeeper
#Initialise Zookeeper storage
sudo zookeeper-server-initialize --myid=$(cat /etc/zookeeper/conf/myid)

#Ensure the Zookeeper service can run properly as non-root
sudo chown -R zookeeper:zookeeper /var/lib/zookeeper
sudo chown -R zookeeper:zookeeper /var/log/zookeeper


### Configure boot
#Disable Mesos Slave service at the Masters (installed, but not needed)
sudo mv /etc/init/mesos-slave.conf /etc/init/mesos-slave.conf.disable

#Configure Marathon boot and HA settings, enable at boot
echo "export MARATHON_HOSTNAME=\"\$(hostname -f)\"" | sudo tee -a /etc/default/marathon > /dev/null
echo "export MARATHON_MASTER=\"\$(cat /etc/marathon/conf/master)\"" | sudo tee -a /etc/default/marathon > /dev/null
echo "export MARATHON_ZK=\"\$(cat /etc/marathon/conf/zk)\"" | sudo tee -a /etc/default/marathon > /dev/null
echo "export MARATHON_MESOS_USER=\"root\"" | sudo tee -a /etc/default/marathon > /dev/null
sudo cp -f $BASE_DIR/marathon /etc/init.d/marathon
sudo chmod +x /etc/init.d/marathon
sudo chkconfig --add /etc/init.d/marathon
sudo chkconfig --levels 2345 marathon on


### Start services
sudo service zookeeper-server start
sudo initctl start mesos-master
sudo service marathon start


### Service failure recovery configuration
CRON_FILE=/var/spool/cron/root
if ! sudo crontab -l; then sudo touch $CRON_FILE; fi
if ! sudo grep -q "marathon failedrestart" $CRON_FILE; then
  echo "* * * * * for i in {1..6}; do /etc/init.d/marathon failedrestart; sleep 10; done" | sudo tee -a $CRON_FILE > /dev/null
fi


### Perform Post-start validation checks
cd $BASE_DIR
#Perform test only on the First Master
if [ "$(cat /etc/zookeeper/conf/myid)" == "1" ]; then
    for i in $(seq 1 60);  do
        echo "Posting Hello Job ($i)"
        if  curl -i -H 'Content-Type: application/json' -d@hello.json $cliqrNodePrivateIp:8080/v2/apps; then
            break;
        fi
        sleep 10
    done 
fi

)>> /var/tmp/master.log 2>&1
