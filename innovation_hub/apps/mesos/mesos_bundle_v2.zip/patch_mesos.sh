#!/bin/bash
(
set -x
source /usr/local/osmosix/etc/userenv
source /usr/local/osmosix/etc/.osmosix.sh

if [ ! -z $INSTALL_TET_AGENT ]; then
  sudo curl -s http://198.19.254.230/apps/tet-agent.sh | sudo bash
fi

sudo yum install nginx -y

# Ensure hostname is registered with DNS
if ! hostname -f > /dev/null 2>&1; then
  dom=$(cat /etc/resolv.conf | egrep -m1 "search|domain" | cut -d' ' -f2)
  echo Adding DNS A Record: ${cliqrNodeHostname}.${dom} => $cliqrNodePrivateIp
  echo -e "update add ${cliqrNodeHostname}.${dom} 86400 a $cliqrNodePrivateIp\nsend" | nsupdate
fi

BASE_DIR=$(cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

marathon=$(echo $CliqrTier_MasterNode_IP | sed -e "s/^/server /" -e "s/,/:8080; server /g" -e 's/$/:8080;/')
sudo sed -i $BASE_DIR/nginx.conf -e "s/__MARATHON__/$marathon/"

mesos=$(echo $CliqrTier_MasterNode_IP | sed -e "s/^/server /" -e "s/,/:5050; server /g" -e 's/$/:5050;/')
sudo sed -i $BASE_DIR/nginx.conf -e "s/__MESOS__/$mesos/"

sudo mv $BASE_DIR/nginx.conf /etc/nginx/
sudo service nginx restart
sleep 1

### Configure automatic failover across Marathon services
sudo cp -f $BASE_DIR/check_update_marathon_ha.sh /root/check_update_marathon_ha.sh
sudo /root/check_update_marathon_ha.sh

CRON_FILE=/var/spool/cron/root
if ! sudo crontab -l; then sudo touch $CRON_FILE; fi
if ! sudo grep -q "check_update_marathon_ha.sh" $CRON_FILE; then
  echo "* * * * * for i in {1..12}; do /root/check_update_marathon_ha.sh >> /var/tmp/check_update_marathon_ha.log; sleep 5; done" | sudo tee -a $CRON_FILE > /dev/null
fi


)>>/var/tmp/nginx_mesos.log 2>&1
