#!/bin/bash
(
set -x
source /usr/local/osmosix/etc/userenv
source /usr/local/osmosix/etc/.osmosix.sh

if [ ! -z $INSTALL_TET_AGENT ]; then
  sudo curl -s http://198.19.254.230/apps/tet-agent.sh | sudo bash
fi

for N in "repos.mesosphere.io" "repos.mesosphere.com"; do
  for X in $(seq 1 1 100); do
    nslookup $N > /dev/null 2>&1
    if [ $? -eq 0 ]; then break; fi
  done
done

BASE_DIR=$(cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

sudo yum -y localinstall $BASE_DIR/mesosphere-el-repo-6-2.noarch.rpm
sudo yum -y install mesos

### Ensure hostname is registered with DNS
if ! hostname -f > /dev/null 2>&1; then
  dom=$(cat /etc/resolv.conf | egrep -m1 "search|domain" | cut -d' ' -f2)
  echo Adding DNS A Record: ${cliqrNodeHostname}.${dom} => $cliqrNodePrivateIp
  echo -e "update add ${cliqrNodeHostname}.${dom} 86400 a $cliqrNodePrivateIp\nsend" | nsupdate
fi

### Configure Zookeeper
echo zk://${CliqrTier_MasterNode_IP} | sed -e 's|,|:2181,|g' -e 's|$|:2181/mesos|' | sudo tee /etc/mesos/zk > /dev/null

### Configure Mesos
echo "$cliqrNodePrivateIp" | sudo tee /etc/mesos-slave/ip | sudo tee /etc/mesos-slave/hostname > /dev/null

### Configure boot
# Disable Master role
sudo mv /etc/init/mesos-master.conf /etc/init/mesos-master.conf.disable

# Start services
sudo initctl start mesos-slave

)>> /var/tmp/slave.log 2>&1
